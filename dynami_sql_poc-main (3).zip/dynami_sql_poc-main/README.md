# dynami_sql_poc
